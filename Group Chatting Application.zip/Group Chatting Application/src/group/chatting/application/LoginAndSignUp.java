
package group.chatting.application;

public class LoginAndSignUp {
    
    public static void main(String[] args){
        
        login LoginFrame = new login();
        LoginFrame.setVisible(true);
        LoginFrame.pack();
        LoginFrame.setLocationRelativeTo(null);
    }
}
